This example shows how to integrate the form validator 
with other scripts.

In this example, we will integrate the validation script with the contact form 
script in the link below
http://www.html-form-guide.com/contact-form/creating-a-contact-form.html

1. The formvalidator.php main validation script is put in the 'include' sub folder

2. formvalidator.php is then included in the contactform.php code
require_once("./include/formvalidator.php");

Open contactform.php in a text editor to see how to use the 
PHP form validator.


