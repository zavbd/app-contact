This example shows how to use the server side php form validation script 
along with the client side JavaScript Form validation script
( http://www.javascript-coder.com/html-form/javascript-form-validation.phtml)

The client side form validation gives immediate form validation feedback. The 
server side validation makes sure that the form submissions are validated 
even if JavaScript is disabled.

See the file contactform.php 
